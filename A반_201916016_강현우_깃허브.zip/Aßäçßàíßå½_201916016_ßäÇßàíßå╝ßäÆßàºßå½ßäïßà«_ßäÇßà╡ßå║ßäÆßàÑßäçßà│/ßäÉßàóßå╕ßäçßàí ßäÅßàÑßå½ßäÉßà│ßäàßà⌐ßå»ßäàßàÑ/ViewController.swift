//
//  ViewController.swift
//  탭바 컨트롤러
//
//  Created by 203a17 on 2022/05/06.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func b1(_ sender: UIButton) {
        tabBarController?.selectedIndex = 1
    }
    @IBAction func b2(_ sender: UIButton) {
        tabBarController?.selectedIndex = 2
    }
    @IBAction func b3(_ sender: UIButton) {
        tabBarController?.selectedIndex = 3
    }
}

